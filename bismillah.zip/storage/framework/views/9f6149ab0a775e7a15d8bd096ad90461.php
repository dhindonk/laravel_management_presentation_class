

<?php $__env->startSection('content'); ?>
    <section class="pc-container" style="top: 10px !important; margin-left: 0 !important; margin: 40px !important;">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Tugas Akhir Mobile Programming</h5>
                        <p class="text-muted">Ajukan presentasi tugas akhir Mobile Programming Anda dengan mudah di sini.</p>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-center mb-4">
                            <a class="btn btn-primary btn-lg" href="<?php echo e(route('mahasiswa.create')); ?>">Buat Pengajuan</a>
                        </div>

                        <div class="table-responsive" style="border-radius: 15px !important">
                            <table id="complex-header" class="table table-striped table-bordered nowrap">
                                <thead class="text-light text-center " style="background: #860000;">
                                    <tr>
                                        <th style="color: white !important">Judul Proyek</th>
                                        <th style="color: white !important">Ketua & Anggota</th>
                                        <th style="color: white !important">Lab</th>
                                        <th style="color: white !important">Jadwal Presentasi</th>
                                        <th style="color: white !important">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($kelompok->isEmpty()): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">
                                                <img src="https://icons.veryicon.com/png/o/business/financial-category/no-data-6.png"
                                                    alt="Data Kosong" style="max-width: 300px;">
                                                <h5>Data Kosong</h5>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="text-align: center; "><?php echo e($k->judul_proyek); ?>

                                                    <?php if($k->selesai == 1): ?>
                                                        <img src="<?php echo e(asset('verified.png')); ?>" width="20"
                                                            height="20">
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <strong><?php echo e($k->ketua); ?> [ <?php echo e($k->npm_ketua); ?> ]</strong>

                                                    <button class="btn btn-link p-0" type="button"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target="#anggotaCollapse<?php echo e($k->id); ?>"
                                                        aria-expanded="false"
                                                        aria-controls="anggotaCollapse<?php echo e($k->id); ?>">
                                                        <i id="iconArrow<?php echo e($k->id); ?>" class="fas fa-chevron-down"
                                                            style="color: var(--primary)"></i>
                                                    </button>
                                                    <br>
                                                    <div class="collapse mt-2" id="anggotaCollapse<?php echo e($k->id); ?>">
                                                        <small>
                                                            <?php if(!empty($k->anggota) && !empty($k->npm_anggota)): ?>
                                                                <?php
                                                                    $anggotaList = json_decode($k->anggota);
                                                                    $npmList = json_decode($k->npm_anggota);
                                                                ?>
                                                                <?php if(count($anggotaList) === count($npmList)): ?>
                                                                    <ul class="list-unstyled">
                                                                        <?php $__currentLoopData = $anggotaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li><?php echo e($anggota); ?> [
                                                                                <?php echo e($npmList[$index]); ?>

                                                                                ]</li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                <?php else: ?>
                                                                    <span>Jumlah anggota dan NPM tidak sesuai</span>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span>Tidak ada anggota atau NPM</span>
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                </td>
                                                <td><?php echo e($k->lab->nama_lab); ?></td>
                                                <td class="text-center">
                                                    <?php if($k->jadwalPresentasi): ?>
                                                        <span><?php echo e($k->jadwalPresentasi->tanggal_presentasi); ?></span><br>
                                                        <small><?php echo e($k->jadwalPresentasi->waktu_presentasi); ?></small>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">Belum diatur</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php if($k->status == 'Pending'): ?>
                                                        <span class="btn btn-warning disabled ">Pending</span>
                                                    <?php elseif($k->status == 'Diterima'): ?>
                                                        <span class="btn btn-success disabled ">Diterima</span>
                                                    <?php elseif($k->status == 'Ditolak'): ?>
                                                        <span class="btn btn-danger disabled ">Ditolak</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            const collapses = document.querySelectorAll('[data-bs-toggle="collapse"]');

            collapses.forEach(function(button) {
                button.addEventListener('click', function() {
                    const icon = this.querySelector('i');
                    const targetCollapse = document.querySelector(this.getAttribute(
                        'data-bs-target'));

                    // Toggle icon direction based on collapse state
                    targetCollapse.addEventListener('shown.bs.collapse', function() {
                        icon.classList.remove('fa-chevron-down');
                        icon.classList.add('fa-chevron-up');
                    });

                    targetCollapse.addEventListener('hidden.bs.collapse', function() {
                        icon.classList.remove('fa-chevron-up');
                        icon.classList.add('fa-chevron-down');
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mobpro\resources\views\mahasiswa\index.blade.php ENDPATH**/ ?>