

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Manajemen Presentasi</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/style.css')); ?>">
        <!-- data tables css -->
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/plugins/dataTables.bootstrap5.min.css')); ?>">
        <!-- [Font] Family -->
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/inter/inter.css')); ?>" id="main-font-link" />
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/tabler-icons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/fontawesome.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/material.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/style-preset.css')); ?>">
        <link rel="icon" href="<?php echo e(asset('logo.png')); ?>" type="image/x-icon">
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-14K1GBX9FG"></script>
        <?php echo $__env->yieldContent('style'); ?>
    </head>

    <body>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" defer></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php if(session('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: '<?php echo e(session('success')); ?>',
                    timer: 3000,
                    showConfirmButton: false,
                });
            </script>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: '<?php echo e(session('error')); ?>',
                    timer: 3000,
                    showConfirmButton: false,
                });
            </script>
        <?php endif; ?>

        <script>
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });
        </script>
    </body>

</html>
<?php /**PATH C:\laragon\www\mobpro\resources\views\layouts\app.blade.php ENDPATH**/ ?>